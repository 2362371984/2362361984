"""
放置游戏核心逻辑
"""
import time
import json
from typing import Dict, List, Optional
from game_data import (
    BUILDINGS, CLICK_UPGRADES, PRODUCTION_UPGRADES,
    BUILDING_UPGRADES, ACHIEVEMENTS, SHOP_ITEMS
)


def format_number(num: float) -> str:
    """格式化大数字显示"""
    if num < 1000:
        return f"{int(num)}"
    elif num < 1000000:
        return f"{num/1000:.2f}K"
    elif num < 1000000000:
        return f"{num/1000000:.2f}M"
    elif num < 1000000000000:
        return f"{num/1000000000:.2f}B"
    else:
        return f"{num/1000000000000:.2f}T"


class IdleGame:
    """放置游戏主类"""
    
    def __init__(self):
        # 基础资源
        self.gold = 0
        self.gems = 0
        self.total_gold_earned = 0  # 累计获得的金币
        
        # 建筑数量 {building_id: count}
        self.buildings = {key: 0 for key in BUILDINGS.keys()}
        
        # 已购买的升级 [upgrade_id, ...]
        self.purchased_upgrades = []
        
        # 已解锁的成就 [achievement_id, ...]
        self.unlocked_achievements = []
        
        # 统计数据
        self.total_clicks = 0
        self.playtime = 0.0  # 秒
        self.last_update_time = time.time()
        self.last_save_time = time.time()
        
        # 激活的临时效果 {item_id: end_time}
        self.active_effects = {}
        
        # 永久解锁 [item_id, ...]
        self.permanent_unlocks = []
    
    @property
    def click_power(self) -> float:
        """计算当前点击收益"""
        base = 1
        
        # 点击升级加成
        for upgrade in CLICK_UPGRADES:
            if upgrade["id"] in self.purchased_upgrades:
                base += upgrade.get("bonus", 0)
        
        # 点击倍率
        multiplier = 1.0
        for upgrade in CLICK_UPGRADES:
            if upgrade["id"] in self.purchased_upgrades:
                multiplier *= upgrade.get("multiplier", 1.0)
        
        # 成就加成
        for ach in ACHIEVEMENTS:
            if ach["id"] in self.unlocked_achievements:
                reward = ach.get("reward", {})
                base += reward.get("click_bonus", 0)
        
        # 临时效果加成
        for item_id, end_time in self.active_effects.items():
            if time.time() < end_time:
                item = next((i for i in SHOP_ITEMS if i["id"] == item_id), None)
                if item:
                    multiplier *= item["effect"].get("click_multiplier", 1.0)
        
        return base * multiplier
    
    @property
    def production_rate(self) -> float:
        """计算当前每秒产出"""
        total = 0
        
        # 每种建筑的产出
        for building_id, count in self.buildings.items():
            if count > 0:
                building = BUILDINGS[building_id]
                base_prod = building["base_production"]
                
                # 建筑专属升级
                building_multiplier = 1.0
                if building_id in BUILDING_UPGRADES:
                    for upgrade in BUILDING_UPGRADES[building_id]:
                        if upgrade["id"] in self.purchased_upgrades:
                            building_multiplier *= upgrade["multiplier"]
                
                total += base_prod * count * building_multiplier
        
        # 全局生产倍率
        global_multiplier = 1.0
        for upgrade in PRODUCTION_UPGRADES:
            if upgrade["id"] in self.purchased_upgrades:
                global_multiplier *= upgrade["multiplier"]
        
        # 成就加成
        achievement_bonus = 0
        for ach in ACHIEVEMENTS:
            if ach["id"] in self.unlocked_achievements:
                reward = ach.get("reward", {})
                achievement_bonus += reward.get("production_bonus", 0)
        
        global_multiplier *= (1 + achievement_bonus)
        
        # 临时效果加成
        for item_id, end_time in self.active_effects.items():
            if time.time() < end_time:
                item = next((i for i in SHOP_ITEMS if i["id"] == item_id), None)
                if item:
                    global_multiplier *= item["effect"].get("production_multiplier", 1.0)
        
        total *= global_multiplier
        
        # 自动点击器
        if "auto_clicker" in self.permanent_unlocks:
            total += self.click_power * 10  # 每秒 10 次点击
        
        return total
    
    @property
    def total_buildings(self) -> int:
        """总建筑数量"""
        return sum(self.buildings.values())
    
    def manual_click(self):
        """手动点击"""
        earned = self.click_power
        self.gold += earned
        self.total_gold_earned += earned
        self.total_clicks += 1
        
        self.check_achievements()
        self.check_gem_milestones()
    
    def update(self, dt: float):
        """更新游戏状态
        
        Args:
            dt: 时间增量（秒）
        """
        self.playtime += dt
        
        # 自动生产
        production = self.production_rate * dt
        self.gold += production
        self.total_gold_earned += production
        
        # 检查成就
        self.check_achievements()
    
    def can_buy_building(self, building_id: str) -> bool:
        """是否可以购买建筑"""
        if building_id not in BUILDINGS:
            return False
        
        building = BUILDINGS[building_id]
        
        # 检查解锁条件
        if self.total_gold_earned < building["unlock_gold"]:
            return False
        
        # 检查金币是否足够
        cost = self.get_building_cost(building_id)
        
        # 成就的建筑成本减免
        discount = 0
        for ach in ACHIEVEMENTS:
            if ach["id"] in self.unlocked_achievements:
                reward = ach.get("reward", {})
                discount += reward.get("building_cost_reduction", 0)
        
        cost *= (1 - discount)
        
        return self.gold >= cost
    
    def get_building_cost(self, building_id: str) -> float:
        """获取建筑当前价格"""
        building = BUILDINGS[building_id]
        count = self.buildings[building_id]
        return building["base_cost"] * (building["cost_growth"] ** count)
    
    def buy_building(self, building_id: str) -> bool:
        """购买建筑"""
        if not self.can_buy_building(building_id):
            return False
        
        cost = self.get_building_cost(building_id)
        
        # 成就的建筑成本减免
        discount = 0
        for ach in ACHIEVEMENTS:
            if ach["id"] in self.unlocked_achievements:
                reward = ach.get("reward", {})
                discount += reward.get("building_cost_reduction", 0)
        
        cost *= (1 - discount)
        
        self.gold -= cost
        self.buildings[building_id] += 1
        
        self.check_achievements()
        return True
    
    def can_buy_upgrade(self, upgrade_id: str) -> bool:
        """是否可以购买升级"""
        if upgrade_id in self.purchased_upgrades:
            return False
        
        # 查找升级
        upgrade = None
        for u in CLICK_UPGRADES + PRODUCTION_UPGRADES:
            if u["id"] == upgrade_id:
                upgrade = u
                break
        
        if not upgrade:
            # 检查建筑升级
            for building_upgrades in BUILDING_UPGRADES.values():
                for u in building_upgrades:
                    if u["id"] == upgrade_id:
                        upgrade = u
                        break
        
        if not upgrade:
            return False
        
        # 检查前置条件
        if "require" in upgrade:
            if upgrade["require"] not in self.purchased_upgrades:
                return False
        
        # 检查金币
        return self.gold >= upgrade["cost"]
    
    def buy_upgrade(self, upgrade_id: str) -> bool:
        """购买升级"""
        if not self.can_buy_upgrade(upgrade_id):
            return False
        
        # 查找升级
        upgrade = None
        for u in CLICK_UPGRADES + PRODUCTION_UPGRADES:
            if u["id"] == upgrade_id:
                upgrade = u
                break
        
        if not upgrade:
            for building_upgrades in BUILDING_UPGRADES.values():
                for u in building_upgrades:
                    if u["id"] == upgrade_id:
                        upgrade = u
                        break
        
        if not upgrade:
            return False
        
        self.gold -= upgrade["cost"]
        self.purchased_upgrades.append(upgrade_id)
        
        return True
    
    def check_achievements(self):
        """检查并解锁成就"""
        for ach in ACHIEVEMENTS:
            if ach["id"] in self.unlocked_achievements:
                continue
            
            condition = ach["condition"]
            cond_type = condition["type"]
            value = condition["value"]
            
            unlocked = False
            if cond_type == "total_gold":
                unlocked = self.total_gold_earned >= value
            elif cond_type == "total_clicks":
                unlocked = self.total_clicks >= value
            elif cond_type == "total_buildings":
                unlocked = self.total_buildings >= value
            elif cond_type == "production_rate":
                unlocked = self.production_rate >= value
            
            if unlocked:
                self.unlocked_achievements.append(ach["id"])
                # 可以在这里触发成就通知
    
    def check_gem_milestones(self):
        """检查宝石里程碑"""
        milestones = [1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000]
        
        for milestone in milestones:
            if self.total_gold_earned >= milestone:
                # 简单实现：每个里程碑给 10 宝石（可以优化为只触发一次）
                # 这里需要记录已领取的里程碑
                pass
    
    def calculate_offline_gold(self, offline_seconds: float) -> float:
        """计算离线收益
        
        Args:
            offline_seconds: 离线时长（秒）
            
        Returns:
            离线获得的金币
        """
        max_offline = 8 * 3600  # 8 小时
        offline_seconds = min(offline_seconds, max_offline)
        
        # 离线效率 50%
        efficiency = 0.5
        
        # 成就加成
        for ach in ACHIEVEMENTS:
            if ach["id"] in self.unlocked_achievements:
                reward = ach.get("reward", {})
                efficiency += reward.get("offline_efficiency_bonus", 0)
        
        return self.production_rate * offline_seconds * efficiency
    
    def apply_offline_rewards(self):
        """应用离线收益"""
        current_time = time.time()
        offline_seconds = current_time - self.last_save_time
        
        if offline_seconds < 60:  # 少于 1 分钟不计算
            return 0
        
        offline_gold = self.calculate_offline_gold(offline_seconds)
        
        self.gold += offline_gold
        self.total_gold_earned += offline_gold
        self.last_save_time = current_time
        
        return offline_gold
    
    def to_dict(self) -> Dict:
        """序列化为字典"""
        return {
            "version": "1.0",
            "gold": self.gold,
            "gems": self.gems,
            "total_gold_earned": self.total_gold_earned,
            "buildings": self.buildings,
            "purchased_upgrades": self.purchased_upgrades,
            "unlocked_achievements": self.unlocked_achievements,
            "total_clicks": self.total_clicks,
            "playtime": self.playtime,
            "last_save_time": self.last_save_time,
            "active_effects": self.active_effects,
            "permanent_unlocks": self.permanent_unlocks
        }
    
    @classmethod
    def from_dict(cls, data: Dict):
        """从字典反序列化"""
        game = cls()
        
        game.gold = data.get("gold", 0)
        game.gems = data.get("gems", 0)
        game.total_gold_earned = data.get("total_gold_earned", 0)
        game.buildings = data.get("buildings", {key: 0 for key in BUILDINGS.keys()})
        game.purchased_upgrades = data.get("purchased_upgrades", [])
        game.unlocked_achievements = data.get("unlocked_achievements", [])
        game.total_clicks = data.get("total_clicks", 0)
        game.playtime = data.get("playtime", 0.0)
        game.last_save_time = data.get("last_save_time", time.time())
        game.active_effects = data.get("active_effects", {})
        game.permanent_unlocks = data.get("permanent_unlocks", [])
        
        return game
    
    def save(self, filename: str = "data/save.json"):
        """保存游戏"""
        import os
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
    
    @classmethod
    def load(cls, filename: str = "data/save.json"):
        """加载游戏"""
        import os
        
        if not os.path.exists(filename):
            return cls()
        
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            game = cls.from_dict(data)
            
            # 应用离线收益
            offline_gold = game.apply_offline_rewards()
            
            return game
        except Exception as e:
            print(f"加载存档失败: {e}")
            return cls()
