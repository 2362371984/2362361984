"""
超简化命令行版游戏 - 可在任何 Python 环境运行
包括 Termux、Pydroid 3、PC
"""
import time
import json
import os

class MiniGame:
    def __init__(self):
        self.gold = 0
        self.buildings = {"miner": 0, "farm": 0, "factory": 0}
        self.clicks = 0
        self.load()
    
    def prod_rate(self):
        return self.buildings["miner"] * 0.1 + self.buildings["farm"] * 1 + self.buildings["factory"] * 8
    
    def cost(self, building):
        base = {"miner": 10, "farm": 100, "factory": 1000}[building]
        return int(base * (1.15 ** self.buildings[building]))
    
    def buy(self, building):
        cost = self.cost(building)
        if self.gold >= cost:
            self.gold -= cost
            self.buildings[building] += 1
            return True
        return False
    
    def click(self):
        self.gold += 1
        self.clicks += 1
    
    def idle(self, seconds):
        self.gold += self.prod_rate() * seconds
    
    def save(self):
        with open("save.json", "w") as f:
            json.dump({"gold": self.gold, "buildings": self.buildings, "clicks": self.clicks}, f)
    
    def load(self):
        if os.path.exists("save.json"):
            try:
                with open("save.json") as f:
                    data = json.load(f)
                    self.gold = data["gold"]
                    self.buildings = data["buildings"]
                    self.clicks = data["clicks"]
            except:
                pass

def main():
    game = MiniGame()
    print("\n=== 点金术士 Mini 版 ===\n")
    
    while True:
        print(f"\n💰 金币: {int(game.gold)} | 每秒: +{game.prod_rate():.1f}")
        print(f"矿工x{game.buildings['miner']} 农场x{game.buildings['farm']} 工厂x{game.buildings['factory']}\n")
        print("1.点击(+1金币) 2.买矿工({}) 3.买农场({}) 4.买工厂({}) 5.挂机10秒 0.退出".format(
            game.cost("miner"), game.cost("farm"), game.cost("factory")))
        
        choice = input("选择: ").strip()
        
        if choice == "1":
            game.click()
            print("💰 +1")
        elif choice == "2":
            if game.buy("miner"):
                print("✓ 购买成功")
            else:
                print("✗ 金币不足")
        elif choice == "3":
            if game.buy("farm"):
                print("✓ 购买成功")
            else:
                print("✗ 金币不足")
        elif choice == "4":
            if game.buy("factory"):
                print("✓ 购买成功")
            else:
                print("✗ 金币不足")
        elif choice == "5":
            for i in range(10):
                game.idle(1)
                print(f"[{i+1}/10] {int(game.gold)} 金币")
                time.sleep(1)
        elif choice == "0":
            game.save()
            print("已保存，再见！")
            break
        
        game.save()

if __name__ == "__main__":
    main()
