[app]

# 应用标题
title = 点金术士

# 包名（反向域名格式）
package.name = luckytapper

# 包域名
package.domain = com.idlegame

# 源代码目录
source.dir = .

# 源代码包含的文件扩展名
source.include_exts = py,png,jpg,kv,atlas,json

# 应用版本
version = 1.0

# 应用要求的 Python 版本
requirements = python3,kivy==2.3.0

# Android 权限
android.permissions = INTERNET,WRITE_EXTERNAL_STORAGE

# 支持的 Android 架构
android.archs = arm64-v8a,armeabi-v7a

# Android API 版本
android.api = 33
android.minapi = 21

# NDK 版本
android.ndk = 25b

# 应用图标（需要自己准备，这里用默认）
# icon.filename = %(source.dir)s/data/icon.png

# 启动画面（需要自己准备）
# presplash.filename = %(source.dir)s/data/presplash.png

# 屏幕方向（portrait=竖屏, landscape=横屏, sensor=自动）
orientation = portrait

# 全屏模式
fullscreen = 0

# Android 服务（不需要后台服务可以注释掉）
# android.services = 

# 日志等级
log_level = 2

# 警告级别
warn_on_root = 1

[buildozer]

# 日志等级
log_level = 2

# 警告忽略
warn_on_root = 1
