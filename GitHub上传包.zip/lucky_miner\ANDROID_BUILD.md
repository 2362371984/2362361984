# Android 打包说明

## 方式一：使用 WSL（推荐，Windows 用户）

### 1. 安装 WSL2 和 Ubuntu

```powershell
# 在 PowerShell（管理员）中运行
wsl --install -d Ubuntu-22.04
```

重启后设置 Ubuntu 用户名和密码。

### 2. 在 WSL 中安装依赖

```bash
# 进入 WSL
wsl

# 更新系统
sudo apt update && sudo apt upgrade -y

# 安装必要工具
sudo apt install -y python3-pip openjdk-11-jdk git zip unzip

# 安装 Buildozer 和 Cython
pip3 install --upgrade pip
pip3 install buildozer cython==0.29.33

# 安装 Android 依赖
sudo apt install -y build-essential libssl-dev libffi-dev python3-dev \
    autoconf libtool pkg-config zlib1g-dev libncurses5-dev \
    libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev
```

### 3. 复制项目到 WSL

```bash
# 在 WSL 中创建工作目录
mkdir -p ~/projects
cd ~/projects

# 从 Windows 复制项目（假设项目在 D:\path\to\lucky_miner）
cp -r /mnt/d/360MoveData/Users/23623/Documents/deepseek-harness/default-workspace/mobile-card-game/lucky_miner ./

cd lucky_miner
```

### 4. 打包 APK

```bash
# 首次打包（会下载 Android SDK/NDK，需要 1-2 小时和 5GB 空间）
buildozer -v android debug

# 后续打包（5-10 分钟）
buildozer android debug

# 如果遇到问题，清理后重试
buildozer android clean
buildozer -v android debug
```

### 5. 获取 APK

```bash
# APK 位置
ls -lh bin/*.apk

# 复制到 Windows（假设要放到桌面）
cp bin/luckytapper-1.0-arm64-v8a-debug.apk /mnt/c/Users/23623/Desktop/
```

---

## 方式二：使用 GitHub Actions（免费云端构建）

### 1. 创建 .github/workflows/build.yml

```yaml
name: Build APK

on:
  push:
    branches: [ main ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install Buildozer
        run: |
          pip install buildozer cython==0.29.33
          sudo apt update
          sudo apt install -y openjdk-11-jdk
      
      - name: Build APK
        run: |
          cd lucky_miner
          buildozer android debug
      
      - name: Upload APK
        uses: actions/upload-artifact@v3
        with:
          name: apk
          path: lucky_miner/bin/*.apk
```

提交到 GitHub 后，每次 push 都会自动构建 APK。

---

## 方式三：使用 Google Colab（在线体验）

在 Colab 中运行：

```python
!pip install buildozer cython==0.29.33
!apt install -y openjdk-11-jdk

# 上传项目文件到 Colab
from google.colab import files
uploaded = files.upload()

# 解压并构建
!unzip lucky_miner.zip
%cd lucky_miner
!buildozer android debug

# 下载 APK
from google.colab import files
files.download('bin/luckytapper-1.0-arm64-v8a-debug.apk')
```

---

## 方式四：使用 Pydroid 3（直接在手机上）

1. 在 Play Store 安装 **Pydroid 3**
2. 安装 Kivy 插件（应用内购）
3. 将项目文件复制到手机
4. 在 Pydroid 3 中运行 `main.py`

缺点：每次启动都要通过 Pydroid，不是独立 APK

---

## 常见问题

### Q: Buildozer 报错 "Command failed: ..."
**A:** 清理后重试：
```bash
buildozer android clean
rm -rf .buildozer
buildozer -v android debug
```

### Q: APK 安装后闪退
**A:** 检查日志：
```bash
adb logcat | grep python
```

常见原因：
1. 缺少 `requirements` 中的依赖
2. Python 3.12 不兼容（改用 3.11）
3. Kivy 版本问题（用 2.2.1 或 2.3.0）

### Q: 首次打包太慢
**A:** 正常现象，需要下载：
- Android SDK (~1GB)
- Android NDK (~2GB)
- Python-for-android (~500MB)
- 各种编译工具

建议在网络好的时候开始，或使用清华/阿里云镜像。

### Q: 能在 Windows 直接打包吗？
**A:** 不能。Buildozer 依赖 Linux 工具链，但 WSL 几乎和原生 Linux 一样方便。

---

## 推荐流程（Windows 用户）

1. **快速体验**：使用 Pydroid 3 在手机上直接运行
2. **正式打包**：用 WSL + Buildozer 生成 APK
3. **持续集成**：配置 GitHub Actions 自动构建

---

## 当前项目状态

```
✅ 核心逻辑完成
✅ Kivy UI 完成
✅ PC 上可运行
✅ buildozer.spec 已配置
⏳ 等待打包成 APK
```

下一步：根据你的环境选择上述任意方式打包！
