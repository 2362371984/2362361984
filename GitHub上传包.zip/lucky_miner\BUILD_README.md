# 点金术士 - Android APK 打包

本项目是一个放置挂机游戏，可以打包成 Android APK。

## 📱 快速测试（无需打包）

### 方案 1：在手机上用 Termux 运行

1. 安装 Termux：https://f-droid.org/en/packages/com.termux/
2. 在 Termux 中运行：
```bash
pkg install python git
git clone <你的仓库地址>
cd lucky_miner
python simple_game.py
```

### 方案 2：在手机上用 Pydroid 3 运行

1. Play Store 安装 Pydroid 3
2. 将项目文件复制到手机
3. 在 Pydroid 3 中打开 `simple_game.py` 运行

---

## 🔨 打包成 APK

### 方式 1：使用 GitHub Actions（推荐，自动化）

1. **将项目推送到 GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/你的用户名/lucky-tapper.git
   git push -u origin main
   ```

2. **启用 GitHub Actions**
   - 进入仓库页面
   - 点击 "Actions" 标签
   - 首次会自动运行构建

3. **下载 APK**
   - 等待构建完成（约 10-15 分钟）
   - 点击最新的构建记录
   - 在 "Artifacts" 区域下载 `lucky-tapper-apk`

### 方式 2：使用 WSL（本地构建）

如果你想在本地打包，需要先安装 WSL：

```powershell
# 在 PowerShell 管理员模式运行
wsl --install -d Ubuntu-22.04
```

重启后在 WSL 中：

```bash
# 安装依赖
sudo apt update
sudo apt install -y python3-pip openjdk-17-jdk git
pip3 install buildozer cython==0.29.33

# 复制项目到 WSL
cd ~
cp -r /mnt/d/360MoveData/Users/23623/Documents/deepseek-harness/default-workspace/mobile-card-game/lucky_miner ./

# 构建
cd lucky_miner
buildozer -v android debug

# APK 位置
ls -lh bin/*.apk
```

首次构建需要下载 Android SDK/NDK，约 1-2 小时。

---

## 📦 项目结构

```
lucky_miner/
├── main.py              # Kivy 图形界面版本
├── simple_game.py       # 纯文本版本（手机可直接运行）
├── game_logic.py        # 游戏核心逻辑
├── game_data.py         # 数值配置
├── buildozer.spec       # Android 打包配置
├── requirements.txt     # Python 依赖
└── data/
    └── save.json        # 存档文件（自动生成）
```

---

## 🎮 游戏说明

### 核心玩法
- 点击屏幕获得金币
- 购买建筑自动产出金币
- 解锁升级提升效率
- 完成成就获得永久加成
- 离线 8 小时继续积累（50% 效率）

### 10 种建筑
```
矿工          10 金币      0.1/秒
农场          100 金币     1/秒
工厂          1K 金币      8/秒
银行          12K 金币     50/秒
矿山          130K 金币    300/秒
魔法塔        1.4M 金币    1.5K/秒
炼金实验室    20M 金币     8K/秒
传送门        330M 金币    40K/秒
时间机器      5.1B 金币    200K/秒
反物质转换器  75B 金币     1M/秒
```

每购买一个建筑，价格增长 15%。

---

## ⚙️ 配置说明

### buildozer.spec 关键配置

```ini
title = 点金术士                    # 应用名称
package.name = luckytapper          # 包名
package.domain = com.idlegame       # 域名
requirements = python3,kivy==2.3.0  # 依赖
android.archs = arm64-v8a,armeabi-v7a  # 支持的架构
orientation = portrait              # 竖屏
```

### GitHub Actions 配置

- 每次 push 到 main/master 分支自动构建
- 构建时间：约 10-15 分钟
- 生成的 APK 保存在 Artifacts 中

---

## 🐛 常见问题

### Q: GitHub Actions 构建失败
**A:** 检查 Actions 日志，常见原因：
- `buildozer.spec` 配置错误
- 依赖版本不兼容
- Python 3.12 不兼容（改用 3.11）

### Q: APK 安装后闪退
**A:** 检查手机日志：
```bash
adb logcat | grep python
```

常见原因：
- 缺少 requirements 中的依赖
- Kivy 版本不兼容

### Q: 首次构建太慢
**A:** 正常现象，GitHub Actions 需要下载 Android SDK/NDK（约 3GB）。后续构建会快很多。

### Q: 能直接在 Windows 打包吗？
**A:** 不能。Buildozer 只支持 Linux/macOS，但可以用 WSL 或 GitHub Actions。

---

## 📝 开发日志

- ✅ 核心数值系统完成
- ✅ Kivy UI 完成
- ✅ 纯文本版本完成（用于快速测试）
- ✅ GitHub Actions 配置完成
- ⏳ 等待首次 APK 构建

---

## 📄 许可

本项目为学习/演示项目，代码可自由使用和修改。
