"""
游戏数据配置 - 建筑、升级、成就
"""

# 建筑配置
BUILDINGS = {
    "miner": {
        "name": "矿工",
        "base_cost": 10,
        "base_production": 0.1,  # 每秒产出
        "cost_growth": 1.15,
        "unlock_gold": 0
    },
    "farm": {
        "name": "农场",
        "base_cost": 100,
        "base_production": 1,
        "cost_growth": 1.15,
        "unlock_gold": 10
    },
    "factory": {
        "name": "工厂",
        "base_cost": 1000,
        "base_production": 8,
        "cost_growth": 1.15,
        "unlock_gold": 100
    },
    "bank": {
        "name": "银行",
        "base_cost": 12000,
        "base_production": 50,
        "cost_growth": 1.15,
        "unlock_gold": 1000
    },
    "mine": {
        "name": "矿山",
        "base_cost": 130000,
        "base_production": 300,
        "cost_growth": 1.15,
        "unlock_gold": 10000
    },
    "magic_tower": {
        "name": "魔法塔",
        "base_cost": 1400000,
        "base_production": 1500,
        "cost_growth": 1.15,
        "unlock_gold": 100000
    },
    "alchemy_lab": {
        "name": "炼金实验室",
        "base_cost": 20000000,
        "base_production": 8000,
        "cost_growth": 1.15,
        "unlock_gold": 1000000
    },
    "portal": {
        "name": "传送门",
        "base_cost": 330000000,
        "base_production": 40000,
        "cost_growth": 1.15,
        "unlock_gold": 10000000
    },
    "time_machine": {
        "name": "时间机器",
        "base_cost": 5100000000,
        "base_production": 200000,
        "cost_growth": 1.15,
        "unlock_gold": 100000000
    },
    "antimatter": {
        "name": "反物质转换器",
        "base_cost": 75000000000,
        "base_production": 1000000,
        "cost_growth": 1.15,
        "unlock_gold": 1000000000
    }
}

# 点击升级
CLICK_UPGRADES = [
    {
        "id": "click_1",
        "name": "强化手指",
        "cost": 100,
        "bonus": 1,  # 额外点击收益
        "description": "点击 +1"
    },
    {
        "id": "click_2",
        "name": "钢铁手套",
        "cost": 500,
        "bonus": 2,
        "description": "点击 +2",
        "require": "click_1"
    },
    {
        "id": "click_3",
        "name": "魔法触碰",
        "cost": 10000,
        "bonus": 5,
        "description": "点击 +5",
        "require": "click_2"
    },
    {
        "id": "click_4",
        "name": "黄金之手",
        "cost": 100000,
        "bonus": 10,
        "description": "点击 +10",
        "require": "click_3"
    },
    {
        "id": "click_5",
        "name": "点金术",
        "cost": 1000000,
        "bonus": 19,  # 累计后总共 38
        "multiplier": 2.0,
        "description": "点击收益 x2",
        "require": "click_4"
    }
]

# 全局生产倍率升级
PRODUCTION_UPGRADES = [
    {
        "id": "prod_1",
        "name": "效率学",
        "cost": 1000,
        "multiplier": 2.0,
        "description": "全局产出 x2"
    },
    {
        "id": "prod_2",
        "name": "工业革命",
        "cost": 50000,
        "multiplier": 2.0,
        "description": "全局产出 x2",
        "require": "prod_1"
    },
    {
        "id": "prod_3",
        "name": "魔法加持",
        "cost": 1000000,
        "multiplier": 2.0,
        "description": "全局产出 x2",
        "require": "prod_2"
    },
    {
        "id": "prod_4",
        "name": "时间加速",
        "cost": 50000000,
        "multiplier": 2.0,
        "description": "全局产出 x2",
        "require": "prod_3"
    },
    {
        "id": "prod_5",
        "name": "维度突破",
        "cost": 5000000000,
        "multiplier": 3.0,
        "description": "全局产出 x3",
        "require": "prod_4"
    }
]

# 建筑专属升级（每种建筑 3 个）
BUILDING_UPGRADES = {
    "miner": [
        {"id": "miner_1", "name": "铁镐", "cost": 100, "multiplier": 2.0},
        {"id": "miner_2", "name": "钻石镐", "cost": 5000, "multiplier": 2.0, "require": "miner_1"},
        {"id": "miner_3", "name": "自动挖掘", "cost": 50000, "multiplier": 2.0, "require": "miner_2"}
    ],
    "farm": [
        {"id": "farm_1", "name": "肥沃土壤", "cost": 1000, "multiplier": 2.0},
        {"id": "farm_2", "name": "自动收割机", "cost": 50000, "multiplier": 2.0, "require": "farm_1"},
        {"id": "farm_3", "name": "魔法种子", "cost": 500000, "multiplier": 2.0, "require": "farm_2"}
    ],
    "factory": [
        {"id": "factory_1", "name": "生产线", "cost": 10000, "multiplier": 2.0},
        {"id": "factory_2", "name": "自动化", "cost": 500000, "multiplier": 2.0, "require": "factory_1"},
        {"id": "factory_3", "name": "AI 管理", "cost": 5000000, "multiplier": 2.0, "require": "factory_2"}
    ]
    # 其他建筑类似...
}

# 成就系统
ACHIEVEMENTS = [
    {
        "id": "gold_100",
        "name": "新手起步",
        "description": "拥有 100 金币",
        "condition": {"type": "total_gold", "value": 100},
        "reward": {"click_bonus": 1}
    },
    {
        "id": "gold_1k",
        "name": "小有成就",
        "description": "拥有 1,000 金币",
        "condition": {"type": "total_gold", "value": 1000},
        "reward": {"production_bonus": 0.1}
    },
    {
        "id": "gold_1m",
        "name": "资本家",
        "description": "拥有 100 万金币",
        "condition": {"type": "total_gold", "value": 1000000},
        "reward": {"production_bonus": 0.2}
    },
    {
        "id": "gold_1b",
        "name": "亿万富翁",
        "description": "拥有 10 亿金币",
        "condition": {"type": "total_gold", "value": 1000000000},
        "reward": {"production_bonus": 0.5}
    },
    {
        "id": "clicks_1k",
        "name": "勤劳的手",
        "description": "手动点击 1,000 次",
        "condition": {"type": "total_clicks", "value": 1000},
        "reward": {"click_bonus": 2}
    },
    {
        "id": "clicks_10k",
        "name": "点击大师",
        "description": "手动点击 10,000 次",
        "condition": {"type": "total_clicks", "value": 10000},
        "reward": {"click_bonus": 5}
    },
    {
        "id": "buildings_100",
        "name": "建筑狂人",
        "description": "拥有 100 座建筑",
        "condition": {"type": "total_buildings", "value": 100},
        "reward": {"building_cost_reduction": 0.05}
    },
    {
        "id": "buildings_500",
        "name": "生产帝国",
        "description": "拥有 500 座建筑",
        "condition": {"type": "total_buildings", "value": 500},
        "reward": {"building_cost_reduction": 0.1}
    },
    {
        "id": "production_1k",
        "name": "全力生产",
        "description": "每秒产出达到 1,000",
        "condition": {"type": "production_rate", "value": 1000},
        "reward": {"unlock": "auto_clicker"}
    },
    {
        "id": "production_1m",
        "name": "产业巨擘",
        "description": "每秒产出达到 100 万",
        "condition": {"type": "production_rate", "value": 1000000},
        "reward": {"offline_efficiency_bonus": 0.2}
    }
]

# 特殊道具（宝石购买）
SHOP_ITEMS = [
    {
        "id": "double_production",
        "name": "双倍产出",
        "cost": 50,  # 宝石
        "duration": 1800,  # 30 分钟
        "effect": {"production_multiplier": 2.0}
    },
    {
        "id": "super_click",
        "name": "超级点击",
        "cost": 30,
        "duration": 600,  # 10 分钟
        "effect": {"click_multiplier": 10.0}
    },
    {
        "id": "auto_clicker",
        "name": "自动点击器",
        "cost": 100,
        "permanent": True,
        "effect": {"auto_clicks_per_second": 10}
    },
    {
        "id": "golden_rain",
        "name": "黄金雨",
        "cost": 80,
        "instant": True,
        "effect": {"instant_offline_hours": 1}
    }
]
