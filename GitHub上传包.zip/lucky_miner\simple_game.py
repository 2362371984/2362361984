"""
简化版游戏 - 可在手机 Python 环境直接运行
移除了 Kivy 依赖，使用纯文本界面
"""
import time
import json
import os
from game_logic import IdleGame, format_number

class SimpleUI:
    """简单的文本界面"""
    
    def __init__(self):
        self.game = IdleGame.load()
        self.running = True
        
        # 应用离线收益
        offline_gold = self.game.apply_offline_rewards()
        if offline_gold > 0:
            print(f'\n欢迎回来！离线获得了 {format_number(offline_gold)} 金币\n')
    
    def clear_screen(self):
        """清屏"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def show_main_menu(self):
        """显示主菜单"""
        self.clear_screen()
        print("=" * 40)
        print("          点金术士 - 放置游戏")
        print("=" * 40)
        print(f"\n💰 金币: {format_number(self.game.gold)}")
        print(f"💎 宝石: {int(self.game.gems)}")
        print(f"📈 每秒: +{format_number(self.game.production_rate)}")
        print(f"👆 点击收益: +{format_number(self.game.click_power)}")
        print(f"🏆 成就: {len(self.game.unlocked_achievements)}/10")
        print("\n" + "=" * 40)
        print("\n菜单:")
        print("1. 点击获得金币")
        print("2. 查看建筑")
        print("3. 查看升级")
        print("4. 查看成就")
        print("5. 自动挂机 10 秒")
        print("0. 保存并退出")
        print("\n" + "=" * 40)
    
    def show_buildings(self):
        """显示建筑列表"""
        self.clear_screen()
        print("=" * 40)
        print("          建筑列表")
        print("=" * 40)
        
        from game_data import BUILDINGS
        
        available = []
        for idx, (building_id, building) in enumerate(BUILDINGS.items(), 1):
            if self.game.total_gold_earned >= building["unlock_gold"]:
                count = self.game.buildings[building_id]
                cost = self.game.get_building_cost(building_id)
                production = building["base_production"] * count if count > 0 else building["base_production"]
                
                available.append((idx, building_id, building, count, cost, production))
                
                status = "✓" if self.game.can_buy_building(building_id) else "✗"
                print(f"\n{idx}. {status} {building['name']} x{count}")
                print(f"   每秒产出: +{format_number(production)}")
                print(f"   价格: {format_number(cost)}")
        
        print("\n" + "=" * 40)
        print("\n输入编号购买，0 返回")
        
        choice = input("\n选择: ").strip()
        
        if choice == "0":
            return
        
        try:
            idx = int(choice)
            for item in available:
                if item[0] == idx:
                    building_id = item[1]
                    if self.game.buy_building(building_id):
                        print(f"\n✓ 购买成功！")
                    else:
                        print(f"\n✗ 金币不足")
                    time.sleep(1)
                    return self.show_buildings()
        except:
            pass
        
        self.show_buildings()
    
    def show_upgrades(self):
        """显示升级列表"""
        self.clear_screen()
        print("=" * 40)
        print("          升级")
        print("=" * 40)
        
        from game_data import CLICK_UPGRADES, PRODUCTION_UPGRADES
        
        available = []
        idx = 1
        
        print("\n【点击升级】")
        for upgrade in CLICK_UPGRADES:
            if upgrade["id"] not in self.game.purchased_upgrades:
                if "require" not in upgrade or upgrade["require"] in self.game.purchased_upgrades:
                    available.append((idx, upgrade))
                    status = "✓" if self.game.gold >= upgrade["cost"] else "✗"
                    print(f"{idx}. {status} {upgrade['name']}")
                    print(f"   {upgrade['description']}")
                    print(f"   价格: {format_number(upgrade['cost'])}")
                    idx += 1
        
        print("\n【生产倍率升级】")
        for upgrade in PRODUCTION_UPGRADES:
            if upgrade["id"] not in self.game.purchased_upgrades:
                if "require" not in upgrade or upgrade["require"] in self.game.purchased_upgrades:
                    available.append((idx, upgrade))
                    status = "✓" if self.game.gold >= upgrade["cost"] else "✗"
                    print(f"{idx}. {status} {upgrade['name']}")
                    print(f"   {upgrade['description']}")
                    print(f"   价格: {format_number(upgrade['cost'])}")
                    idx += 1
        
        print("\n" + "=" * 40)
        print("\n输入编号购买，0 返回")
        
        choice = input("\n选择: ").strip()
        
        if choice == "0":
            return
        
        try:
            idx = int(choice)
            for item in available:
                if item[0] == idx:
                    upgrade = item[1]
                    if self.game.buy_upgrade(upgrade["id"]):
                        print(f"\n✓ 购买成功！")
                    else:
                        print(f"\n✗ 金币不足或条件不满足")
                    time.sleep(1)
                    return self.show_upgrades()
        except:
            pass
        
        self.show_upgrades()
    
    def show_achievements(self):
        """显示成就"""
        self.clear_screen()
        print("=" * 40)
        print("          成就")
        print("=" * 40)
        
        from game_data import ACHIEVEMENTS
        
        for ach in ACHIEVEMENTS:
            unlocked = ach["id"] in self.game.unlocked_achievements
            status = "✓" if unlocked else "✗"
            print(f"\n{status} {ach['name']}")
            print(f"   {ach['description']}")
            if unlocked:
                reward = ach.get("reward", {})
                if "click_bonus" in reward:
                    print(f"   奖励: 点击 +{reward['click_bonus']}")
                if "production_bonus" in reward:
                    print(f"   奖励: 生产 +{int(reward['production_bonus']*100)}%")
        
        print("\n" + "=" * 40)
        input("\n按回车返回...")
    
    def manual_click(self):
        """手动点击"""
        clicks = 10
        print(f"\n连续点击 {clicks} 次...")
        for i in range(clicks):
            self.game.manual_click()
            print(f"💰 +{format_number(self.game.click_power)} (总计: {format_number(self.game.gold)})")
            time.sleep(0.1)
        
        print("\n完成！")
        time.sleep(1)
    
    def auto_idle(self):
        """自动挂机"""
        print("\n自动挂机 10 秒...")
        start_gold = self.game.gold
        
        for i in range(10):
            self.game.update(1.0)
            earned = self.game.gold - start_gold
            print(f"[{i+1}/10] 金币: {format_number(self.game.gold)} (+{format_number(earned)})")
            time.sleep(1)
        
        total_earned = self.game.gold - start_gold
        print(f"\n✓ 挂机完成！共获得 {format_number(total_earned)} 金币")
        time.sleep(2)
    
    def run(self):
        """运行游戏"""
        while self.running:
            self.show_main_menu()
            choice = input("\n选择: ").strip()
            
            if choice == "1":
                self.manual_click()
            elif choice == "2":
                self.show_buildings()
            elif choice == "3":
                self.show_upgrades()
            elif choice == "4":
                self.show_achievements()
            elif choice == "5":
                self.auto_idle()
            elif choice == "0":
                print("\n保存游戏...")
                self.game.save()
                print("再见！")
                self.running = False
            else:
                print("\n无效选择")
                time.sleep(1)

if __name__ == "__main__":
    try:
        game = SimpleUI()
        game.run()
    except KeyboardInterrupt:
        print("\n\n游戏已中断，正在保存...")
        game.game.save()
        print("再见！")
