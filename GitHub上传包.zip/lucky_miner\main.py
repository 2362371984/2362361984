"""
放置游戏 - Kivy 主程序
"""
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle

from game_logic import IdleGame, format_number
from game_data import BUILDINGS, CLICK_UPGRADES, PRODUCTION_UPGRADES, BUILDING_UPGRADES

# 设置窗口大小（开发时使用，打包 APK 后会自适应）
Window.size = (360, 640)


class MainScreen(Screen):
    """主游戏界面"""
    
    def __init__(self, game: IdleGame, **kwargs):
        super().__init__(**kwargs)
        self.game = game
        
        # 主布局
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        # 顶部资源显示
        self.top_bar = BoxLayout(size_hint=(1, 0.15), spacing=10)
        self.gold_label = Label(
            text=f'金币: {format_number(self.game.gold)}',
            font_size='18sp',
            bold=True
        )
        self.gems_label = Label(
            text=f'宝石: {int(self.game.gems)}',
            font_size='16sp'
        )
        self.top_bar.add_widget(self.gold_label)
        self.top_bar.add_widget(self.gems_label)
        layout.add_widget(self.top_bar)
        
        # 点击按钮区域
        click_area = BoxLayout(
            orientation='vertical',
            size_hint=(1, 0.35),
            spacing=10
        )
        
        # 大金币按钮
        self.click_button = Button(
            text='💰\n点击获得金币',
            font_size='24sp',
            bold=True,
            background_color=(1, 0.8, 0.2, 1)
        )
        self.click_button.bind(on_press=self.on_click)
        click_area.add_widget(self.click_button)
        
        # 生产信息
        self.production_label = Label(
            text=f'每秒: +{format_number(self.game.production_rate)}',
            font_size='16sp',
            size_hint=(1, 0.3)
        )
        click_area.add_widget(self.production_label)
        
        layout.add_widget(click_area)
        
        # 建筑列表（可滚动）
        scroll = ScrollView(size_hint=(1, 0.5))
        self.building_grid = GridLayout(
            cols=1,
            spacing=10,
            size_hint_y=None,
            padding=10
        )
        self.building_grid.bind(minimum_height=self.building_grid.setter('height'))
        
        self.building_buttons = {}
        self.create_building_list()
        
        scroll.add_widget(self.building_grid)
        layout.add_widget(scroll)
        
        self.add_widget(layout)
        
        # 定时更新
        Clock.schedule_interval(self.update, 0.1)  # 每 0.1 秒更新一次
        Clock.schedule_interval(self.save_game, 5.0)  # 每 5 秒自动保存
    
    def create_building_list(self):
        """创建建筑列表"""
        for building_id, building in BUILDINGS.items():
            # 检查是否解锁
            if self.game.total_gold_earned < building["unlock_gold"]:
                continue
            
            building_layout = BoxLayout(
                orientation='horizontal',
                size_hint_y=None,
                height=80,
                spacing=10
            )
            
            # 建筑信息
            info_layout = BoxLayout(orientation='vertical', size_hint=(0.6, 1))
            
            count = self.game.buildings[building_id]
            production = building["base_production"] * count if count > 0 else building["base_production"]
            
            name_label = Label(
                text=f'{building["name"]} x{count}',
                font_size='16sp',
                bold=True
            )
            prod_label = Label(
                text=f'每秒: +{format_number(production)}',
                font_size='14sp'
            )
            
            info_layout.add_widget(name_label)
            info_layout.add_widget(prod_label)
            
            # 购买按钮
            cost = self.game.get_building_cost(building_id)
            buy_button = Button(
                text=f'购买\n{format_number(cost)}',
                size_hint=(0.4, 1),
                font_size='14sp'
            )
            buy_button.bind(
                on_press=lambda x, bid=building_id: self.buy_building(bid)
            )
            
            building_layout.add_widget(info_layout)
            building_layout.add_widget(buy_button)
            
            self.building_grid.add_widget(building_layout)
            self.building_buttons[building_id] = (name_label, prod_label, buy_button)
    
    def on_click(self, instance):
        """处理点击事件"""
        self.game.manual_click()
        
        # 动画效果（简单的按钮缩放）
        instance.size_hint = (0.95, 0.95)
        Clock.schedule_once(lambda dt: setattr(instance, 'size_hint', (1, 1)), 0.1)
    
    def buy_building(self, building_id):
        """购买建筑"""
        if self.game.buy_building(building_id):
            # 购买成功，更新显示会在 update 中完成
            pass
    
    def update(self, dt):
        """更新界面显示"""
        self.game.update(dt)
        
        # 更新资源显示
        self.gold_label.text = f'金币: {format_number(self.game.gold)}'
        self.gems_label.text = f'宝石: {int(self.game.gems)}'
        self.production_label.text = f'每秒: +{format_number(self.game.production_rate)}'
        
        # 更新点击按钮提示
        click_power = self.game.click_power
        self.click_button.text = f'💰\n点击 +{format_number(click_power)}'
        
        # 更新建筑列表
        for building_id, (name_label, prod_label, buy_button) in self.building_buttons.items():
            building = BUILDINGS[building_id]
            count = self.game.buildings[building_id]
            production = building["base_production"] * count if count > 0 else building["base_production"]
            cost = self.game.get_building_cost(building_id)
            
            name_label.text = f'{building["name"]} x{count}'
            prod_label.text = f'每秒: +{format_number(production)}'
            buy_button.text = f'购买\n{format_number(cost)}'
            
            # 根据是否能购买改变按钮颜色
            if self.game.can_buy_building(building_id):
                buy_button.background_color = (0.2, 0.8, 0.2, 1)
            else:
                buy_button.background_color = (0.5, 0.5, 0.5, 1)
        
        # 检查是否有新建筑解锁
        self.check_new_buildings()
    
    def check_new_buildings(self):
        """检查并添加新解锁的建筑"""
        for building_id, building in BUILDINGS.items():
            if building_id not in self.building_buttons:
                if self.game.total_gold_earned >= building["unlock_gold"]:
                    # 重新创建建筑列表
                    self.building_grid.clear_widgets()
                    self.building_buttons.clear()
                    self.create_building_list()
                    break
    
    def save_game(self, dt):
        """自动保存游戏"""
        self.game.save()


class UpgradeScreen(Screen):
    """升级界面"""
    
    def __init__(self, game: IdleGame, **kwargs):
        super().__init__(**kwargs)
        self.game = game
        
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        # 标题
        title = Label(
            text='升级',
            font_size='24sp',
            bold=True,
            size_hint=(1, 0.1)
        )
        layout.add_widget(title)
        
        # 升级列表
        scroll = ScrollView()
        upgrade_grid = GridLayout(
            cols=1,
            spacing=10,
            size_hint_y=None,
            padding=10
        )
        upgrade_grid.bind(minimum_height=upgrade_grid.setter('height'))
        
        # 点击升级
        for upgrade in CLICK_UPGRADES:
            if "require" in upgrade and upgrade["require"] not in self.game.purchased_upgrades:
                continue
            
            if upgrade["id"] in self.game.purchased_upgrades:
                continue
            
            upgrade_btn = Button(
                text=f'{upgrade["name"]}\n{upgrade["description"]}\n{format_number(upgrade["cost"])} 金币',
                size_hint_y=None,
                height=80
            )
            upgrade_btn.bind(
                on_press=lambda x, uid=upgrade["id"]: self.buy_upgrade(uid)
            )
            upgrade_grid.add_widget(upgrade_btn)
        
        # 生产倍率升级
        for upgrade in PRODUCTION_UPGRADES:
            if "require" in upgrade and upgrade["require"] not in self.game.purchased_upgrades:
                continue
            
            if upgrade["id"] in self.game.purchased_upgrades:
                continue
            
            upgrade_btn = Button(
                text=f'{upgrade["name"]}\n{upgrade["description"]}\n{format_number(upgrade["cost"])} 金币',
                size_hint_y=None,
                height=80
            )
            upgrade_btn.bind(
                on_press=lambda x, uid=upgrade["id"]: self.buy_upgrade(uid)
            )
            upgrade_grid.add_widget(upgrade_btn)
        
        scroll.add_widget(upgrade_grid)
        layout.add_widget(scroll)
        
        # 返回按钮
        back_btn = Button(
            text='返回',
            size_hint=(1, 0.1),
            font_size='18sp'
        )
        back_btn.bind(on_press=self.go_back)
        layout.add_widget(back_btn)
        
        self.add_widget(layout)
    
    def buy_upgrade(self, upgrade_id):
        """购买升级"""
        if self.game.buy_upgrade(upgrade_id):
            # 刷新界面
            self.manager.current = 'main'
            self.manager.current = 'upgrade'
    
    def go_back(self, instance):
        """返回主界面"""
        self.manager.current = 'main'


class IdleGameApp(App):
    """游戏应用主类"""
    
    def build(self):
        # 加载游戏
        self.game = IdleGame.load()
        
        # 检查离线收益
        offline_gold = self.game.apply_offline_rewards()
        if offline_gold > 0:
            print(f'欢迎回来！离线获得了 {format_number(offline_gold)} 金币')
        
        # 创建屏幕管理器
        sm = ScreenManager()
        
        # 添加主界面
        main_screen = MainScreen(self.game, name='main')
        sm.add_widget(main_screen)
        
        # 添加升级界面
        upgrade_screen = UpgradeScreen(self.game, name='upgrade')
        sm.add_widget(upgrade_screen)
        
        return sm
    
    def on_stop(self):
        """应用关闭时保存游戏"""
        self.game.save()
        return True


if __name__ == '__main__':
    IdleGameApp().run()
